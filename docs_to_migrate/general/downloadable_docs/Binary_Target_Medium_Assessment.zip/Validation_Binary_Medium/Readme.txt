This readme describes the steps to be taken to construct the most basic sequence of instances to assess a model predicting a binary target.

The user should know how to create a:

- artifact
- specification
- instance

If not, we refer to the Chiron app documentation.

----------------------------------------------------------------

To construct the pipeline we follow the process as laid down in section "End-to-end workflow in Chiron App" in the documentation.

Setting the stage
-----------------

1. Upload the PPNR train and test datasets as different datasets. This contains some dummy data with some variables, a model target and a model prediction as well as some other variables.
2. Upload the DMM_PPNR as a file inside an artifact. This file adds some business context on the dataset to be used.


Calculate your metrics on the training dataset
----------------------------------------------

3. Create a specification to calculate some metrics on the training dataset.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it as input and output.
   When the specification is opened ('open code') choose the train set from step 1 to interactively run the notebook.
   For the notebook itself: use 'Validation_Binary_Medium_Training_Input.ipynb'.
4. Create an instance that uses the specification from step 3. 
   The output is a freeform artifact containing a .json file which in turn contains the train data metrics.

Model assessment
----------------

5. Create a specification to asses the model.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it as input and output.
   When the specification is opened ('open code') choose the PPNR test set from step 1 as well as the freeform artifact from step 4 as inputs to interactively run the notebook (next to other predefined parameters).
   For the notebook itself: use 'Validation_Binary_Medium.ipynb'.
6. Create an instance that uses the specification from step 4. 
   Run it on the PPNR test set.





