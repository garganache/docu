This readme describes the steps to be taken to run different outlier detection algorithms on a given tabular dataset.

The user should know how to create a:

- artifact
- specification
- instance

If not, we refer to the Chiron app documentation.


* the data quality notebook illustrates several standard tests to be carried out to assess the overall data quality of any given tabular dataset. 
* focus is on the model input variables as defined in the hybrid schema (a json file providing some business context on the dataset's variables meaning)

Setting the stage
-----------------

1. Create an artifact in which you upload (register) the dataset of interest (e.g. PPNR). Tabular data of .csv format is assumed.
  

Create the DQ specification
------------------------------------------------------------------------------------------

2. Create a specification that contains the notebook conducting the DQ analyses.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it takes as input and output.
   When the specification is opened ('open code') choose the dataset from step 1 to interactively run the notebook. Other inputs and their meaning are described in the .json file of the specification (it might therefore be handy to upload the specification as .json).
   Do not forget to 'register version' and after that 'mark the specification as registered'. 
   Up to this point, the content of the notebook itself should not be changed.

Create the DQ analyses instance
------------------------------------------------------------------------------------------

3. Create an instance that uses the specification from step 2. 
   There are two outputs that will be created:
	+ an artifaict which is a copy of the original dataset, enriched with some binary columns indicating wether the observation is deemed a univariate outlier in a given variable.
      + a DQ dictionary, saved as .json. It simply contains some summary of the different DQ analyses. This json can be used in later stages for reference (e.g. are there any new categories appearing for a given categorical variable?)

   The same specification from step 2 can be used to create different instances for the three different datasets. This is an illustration on how to come to a consistent approach in dealing
   with a tabular dataset in general. "All tabular datasets are treated equally" (i.e. the same analyses are executed onto them). It is only up to the user to input some dataset specific
   values, such as the variables of interest. But this only happens at 'instance creation time'.




