This readme describes the steps to be taken to run different outlier detection algorithms on a given tabular dataset.

The user should know how to create a:

- artifact
- specification
- instance

If not, we refer to the Chiron app documentation.


To showcase Explainable AI (XAI), we provide to notebooks:

1. one that creates a model 'CreateBenchmarkModel.ipynb). This model - an sklear pipeline object - is saved as a pickle file. 
2.This model is also retrieved in a second step (XAI_techniques_Binary_sklear_models) to make predictions and assesses it's explainability.
 

Setting the stage
-----------------

1. Create the first specification using the provided json.
2. Upload the notebook after 'open code'.
3. Register the specification, create an instance out of it and run the instance. This will return you the trained sklear model pipeline object.

4. Create the second specification using the provived json.
5. Upload the notebook after 'open code'.
6. Register the specification, create an instance out of it and run the instance. Use the same input data as the one you used to train the model. To show the use cases we used identical dataset (titanic.csv).




