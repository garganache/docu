This readme describes the steps to be taken to construct the most basic sequence of instances to assess a model predicting a binary target.

The user should know how to create a:

- artifact
- specification
- instance

If not, we refer to the Chiron app documentation.

----------------------------------------------------------------

To construct the pipeline we follow the process as laid down in section "End-to-end workflow in Chiron App" in the documentation.

REMARK: this pipeline is an extension to the 'medium_validation' pipeline. Here, as extra a benchmark model is trained and saved into the platform. At model assessment time, this trained model is then loaded to make predictions on the application dataset.

Setting the stage
-----------------

1. Ingest the PPNR train and test datasets as artifacts. This contains some dummy data with some variables, a model target and a model prediction as well as some other variables.
2. Upload the data model mapping under another artifact. 


Calculate your metrics on the training dataset (see other use case for relevant notebooks)
------------------------------------------------------------------------------------------

3. Create a specification to calculate some metrics on the training dataset.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it as input and output.
   When the specification is opened ('open code') choose the train set from step 1 to interactively run the notebook.
   For the notebook itself: use 'Validation_Binary_Medium_Training_Input.ipynb'.
4. Create an instance that uses the specification from step 3. 
   The output is a freeform artifact containing a .json file which in turn contains the train data metrics.

Create a benchmark model
------------------------

5. Create a specification to develop a benchmark model.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it as input and output.
   When the specification is opened ('open code') choose the either the train or test set (or any other dataset that has the original model variables and the target) from step 1 to interactively run the notebook.
   For the notebook itself: use 'create_benchmark_model.ipynb'.
6. Create an instance that uses the specification from step 5. 
   The output of this instance are 3 freeform artifacts each containing a .pickle file that contain 1) the preprocessor object for continous data 2) the preprocessor for categorical data and 3) the benchmark model object.
   Those artifacts will be loaded during model assessment time to apply our benchmark model onto the application data on which the model performance is assessed.	

Model assessment
----------------

7. Create a specification to asses the model.
   The .json file is available should the user create the specification from json (see docs).
   If not, from this .json file is still useful to determine what is the specification signature, i.e. what it as input and output.
   When the specification is opened ('open code') choose the PPNR test set from step 1 as well as the freeform artifacts from step 4 (train data) and 6 (benchmark model) as inputs to interactively run the notebook (next to other predefined parameters).
   For the notebook itself: use 'Validation_Binary_Full.ipynb'.
8. Create an instance that uses the specification from step 4. 
   Use windowing_mode = 'Batchkey' and choose the 'date' column as batchkey variable.
   Run it on the PPNR test set.





